﻿Public Class Form1


    
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        If Not String.IsNullOrWhiteSpace(txtIDNumber.Text.Trim) Then
            If txtIDNumber.Text.Length = 6 Then
                Process.Start("C:\DATA\REFERENCE\FingerPrint\FingerPrint\bin\Debug\Fingerprint.exe", txtIDNumber.Text.TrimStart.TrimEnd)
            Else
                MessageBox.Show("You must enter six(6) character.", "Registration of fingerprint", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Else
            MessageBox.Show("Please enter your employee number.", "Registration of fingerprint", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If

    End Sub
End Class

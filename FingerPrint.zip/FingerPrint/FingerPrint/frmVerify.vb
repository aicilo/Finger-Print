﻿
Public Class frmVerify
    Implements DPFP.Capture.EventHandler
    Private Delegate Sub FunctionCall(ByVal param)

    Private Capturer As DPFP.Capture.Capture
    Private Template As DPFP.Template
    Private Verificator As DPFP.Verification.Verification

    Protected Sub UpdateStatus(ByVal FAR As Integer)
        ' Show "False accept rate" value
        SetStatus(String.Format("False Accept Rate (FAR) = {0}", FAR))
    End Sub
    Protected Sub SetStatus(ByVal status)
        Invoke(New FunctionCall(AddressOf _SetStatus), status)
    End Sub
    Private Sub _SetStatus(ByVal status)
        lblStatus.Text = status
    End Sub

    'Private Sub Process(ByVal Sample As DPFP.Sample)
    '    Dim verified As Boolean = False
    '    Dim FingerprintLocation As String = Application.StartupPath & "\Fingerprint"
    '    Dim dir As New System.IO.DirectoryInfo(FingerprintLocation)
    '    For Each ftp In dir.GetFiles
    '        Using fs As IO.FileStream = IO.File.OpenRead(System.IO.Path.Combine(FingerprintLocation, ftp.Name))
    '            Dim template As New DPFP.Template(fs)
    '            Dim features As DPFP.FeatureSet = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Verification)
    '            If Not features Is Nothing Then
    '                ' Compare the feature set with our template
    '                Dim result As DPFP.Verification.Verification.Result = New DPFP.Verification.Verification.Result()
    '                Verificator.Verify(features, template, result)
    '                UpdateStatus(result.FARAchieved)
    '                If result.Verified Then
    '                    verified = True
    '                    Exit For
    '                End If
    '            End If
    '        End Using
    '    Next
    '    If verified = True Then
    '        MakeReport("The fingerprint was VERIFIED.")
    '        isSuccess(True)
    '    Else
    '        MakeReport("The fingerprint wan NOT VERIFIED.")
    '        isSuccess(False)
    '    End If
    'End Sub


    Private Sub Process(ByVal Sample As DPFP.Sample)
        DrawPicture(ConvertSampleToBitmap(Sample))
        ' Process the sample and create a feature set for the enrollment purpose.
        Dim features As DPFP.FeatureSet = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Verification)

        ' Check quality of the sample and start verification if it's good
        If Not features Is Nothing Then
            ' Compare the feature set with our template
            Dim result As DPFP.Verification.Verification.Result = New DPFP.Verification.Verification.Result()
            Verificator.Verify(features, Template, result)
            UpdateStatus(result.FARAchieved)
            If result.Verified Then
                MakeReport("The fingerprint was VERIFIED.")
                isSuccess(True)
            Else
                MakeReport("The fingerprint wan NOT VERIFIED.")
                isSuccess(False)
            End If
        End If
    End Sub

    Private Sub MakeReport(ByVal status As String)
        Invoke(New FunctionCall(AddressOf _MakeReport), status)
    End Sub

    Private Sub _MakeReport(ByVal status As String)
        lblReport.Text = status

    End Sub

    Private Function ExtractFeatures(ByVal Sample As DPFP.Sample, ByVal Purpose As DPFP.Processing.DataPurpose) As DPFP.FeatureSet
        Try
            Dim extractor As New DPFP.Processing.FeatureExtraction()        ' Create a feature extractor
            Dim feedback As DPFP.Capture.CaptureFeedback = DPFP.Capture.CaptureFeedback.None
            Dim features As New DPFP.FeatureSet()
            extractor.CreateFeatureSet(Sample, Purpose, feedback, features) ' TODO: return features as a result?
            If (feedback = DPFP.Capture.CaptureFeedback.Good) Then
                Return features
            Else
                Return Nothing
            End If
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Sub DrawPicture(ByVal bmp) 'PictureBox
        'Picture.Image = New Bitmap(bmp, Picture.Size)
    End Sub
    Private Function ConvertSampleToBitmap(ByVal Sample As DPFP.Sample) As Bitmap
        Dim convertor As New DPFP.Capture.SampleConversion()    ' Create a sample convertor.
        Dim bitmap As Bitmap = Nothing                          ' TODO: the size doesn't matter
        convertor.ConvertToPicture(Sample, bitmap)              ' TODO: return bitmap as a result
        Return bitmap
    End Function

    Private Sub frmVerify_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim open As New OpenFileDialog()
        open.Filter = "Fingerprint Template File (*.fpt)|*.fpt"
        If open.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Using fs As IO.FileStream = IO.File.OpenRead(open.FileName)
                Dim template As New DPFP.Template(fs)
                OnTemplate(template)
            End Using
        End If

        Try
            Capturer = New DPFP.Capture.Capture()                   ' Create a capture operation.
            Verificator = New DPFP.Verification.Verification()
            If (Not Capturer Is Nothing) Then
                Capturer.EventHandler = Me
                StartCapture() 'Subscribe for capturing events.' Subscribe for capturing events.
                SetPrompt("Scan your fingerprint.")
            Else
                SetPrompt("Can't initiate capture operation!")
            End If
        Catch ex As Exception
            MessageBox.Show("Can't initiate capture operation!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Dispose()

        End Try

    End Sub

    'Private Sub frmVerify_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    Try
    '        Capturer = New DPFP.Capture.Capture()                   ' Create a capture operation.
    '        Verificator = New DPFP.Verification.Verification()
    '        If (Not Capturer Is Nothing) Then
    '            Capturer.EventHandler = Me
    '            StartCapture() 'Subscribe for capturing events.' Subscribe for capturing events.
    '            SetPrompt("Scan your fingerprint.")
    '        Else
    '            SetPrompt("Can't initiate capture operation!")
    '        End If
    '    Catch ex As Exception
    '        MessageBox.Show("Can't initiate capture operation!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        Me.Dispose()
    '    End Try

    'End Sub


    Private Sub StartCapture()
        If (Not Capturer Is Nothing) Then
            Try
                Capturer.StartCapture()
                SetPrompt("Using the fingerprint reader, scan your fingerprint.")
            Catch ex As Exception
                SetPrompt("Can't initiate capture!")
            End Try
        End If
    End Sub

    Private Sub StopCapture()
        If (Not Capturer Is Nothing) Then
            Try
                Capturer.StopCapture()
            Catch ex As Exception
                SetPrompt("Can't initiate capture!")
            End Try
        End If
    End Sub
    Private Sub OnTemplate(ByVal template)
        Invoke(New FunctionCall(AddressOf _OnTemplate), template)
    End Sub
    Private Sub _OnTemplate(ByVal template)
        Me.Template = template
    End Sub
    Private Sub SetPrompt(ByVal text As String)
        Invoke(New FunctionCall(AddressOf _SetPrompt), text)
    End Sub
    Private Sub _SetPrompt(ByVal text As String)
        lblPrompt.Text = text
    End Sub

    Private Sub isSuccess(ByVal success As Boolean)
        Invoke(New FunctionCall(AddressOf _isSuccess), success)
    End Sub

    Private Sub _isSuccess(ByVal success As Boolean)
        If success = True Then
            'MessageBox.Show("Saved!")
            picSuccess.Visible = True
            'Me.Close()
        Else
            picSuccess.Visible = False
        End If
    End Sub


    Private Sub OnComplete(ByVal Capture As Object, ByVal ReaderSerialNumber As String, ByVal Sample As DPFP.Sample) Implements DPFP.Capture.EventHandler.OnComplete
        MakeReport("The fingerprint sample was captured.")
        Process(Sample)
    End Sub

    Private Sub OnFingerGone(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnFingerGone
        MakeReport("The finger was removed from the fingerprint reader.")
        isSuccess(False)
    End Sub

    Private Sub OnFingerTouch(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnFingerTouch
        MakeReport("The fingerprint reader was touched.")
        isSuccess(False)

    End Sub

    Private Sub OnReaderConnect(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnReaderConnect
        MakeReport("The fingerprint reader was connected.")
        isSuccess(False)

    End Sub

    Private Sub OnReaderDisconnect(ByVal Capture As Object, ByVal ReaderSerialNumber As String) Implements DPFP.Capture.EventHandler.OnReaderDisconnect
        MakeReport("The fingerprint reader was disconnected.")
        isSuccess(False)

    End Sub

    Private Sub OnSampleQuality(ByVal Capture As Object, ByVal ReaderSerialNumber As String, ByVal CaptureFeedback As DPFP.Capture.CaptureFeedback) Implements DPFP.Capture.EventHandler.OnSampleQuality
        If CaptureFeedback = DPFP.Capture.CaptureFeedback.Good Then
            MakeReport("The quality of the fingerprint sample is good.")
            isSuccess(False)

        Else
            MakeReport("The quality of the fingerprint sample is poor.")
            isSuccess(False)

        End If
    End Sub
End Class